#pragma once
#include <iostream>

using namespace std;

// PlaylistNode class defines the structure of each node in the playlist linked list.
class PlaylistNode {
public:
  // Attributes to store song details and the pointer to the next node.
  string uniqueID;
  string songName;
  string artistName;
  int songLength;
  PlaylistNode* nextNodePtr;

  // Default constructor initializes node with default values.
  PlaylistNode()
  : uniqueID("none"), songName("none"), artistName("none"), songLength(0), nextNodePtr(nullptr) {}

  // Destructor for PlaylistNode, does nothing special.
  ~PlaylistNode() {}

  // Parameterized constructor initializes node with specific song details.
  PlaylistNode(string newID, string newSong, string newArtist, int songSize)
  : uniqueID(newID), songName(newSong), artistName(newArtist), songLength(songSize), nextNodePtr(nullptr) {}

  // SetNext modifies the next node pointer to link nodes in the list.
  void SetNext(PlaylistNode* newNode) {
    newNode->nextNodePtr = this->nextNodePtr;
    this->nextNodePtr = newNode;
  }

  // InsertAfter places a new node immediately after the current node.
  void InsertAfter(PlaylistNode* newNode) {
    newNode->nextNodePtr = this->nextNodePtr;
    this->nextNodePtr = newNode;
  }

  // Getters provide access to node attributes.
  const string& GetID() const { return uniqueID; }
  const string& GetArtistName() const { return artistName; }
  const string& GetSongName() const { return songName; }
  int GetSongLength() const { return songLength; }
  PlaylistNode* GetNext() { return nextNodePtr; }
  const PlaylistNode* GetNext() const { return nextNodePtr; }

  // PrintPlaylistNode outputs the song details to the console.
  void PrintPlaylistNode() const {
    cout << endl;
    cout << "Unique ID: " << uniqueID << '\n';
    cout << "Song Name: " << songName << '\n';
    cout << "Artist Name: " << artistName << '\n';
    cout << "Song Length (in seconds): " << songLength << "\n" << endl;
  }
};

// Playlist class manages a linked list of PlaylistNodes to represent a playlist.
class Playlist {
  // Pointers to the head and the tail of the singly linked list
  PlaylistNode* head;
  PlaylistNode* tail;

public:
  // Constructor initializes an empty playlist.
  Playlist() : head(nullptr), tail(nullptr) {}

  // Destructor deletes all nodes to free memory.
  ~Playlist() {
    PlaylistNode* curr = head;
    while (curr != nullptr) {
      PlaylistNode* next = curr->GetNext();
      delete curr;  // Free the memory allocated for the node.
      curr = next;
    }
    head = nullptr;
    tail = nullptr;
  }
  // Specifies that there will not be a C++ default one written
  Playlist(const Playlist&) = delete;
  Playlist& operator=(const Playlist&) = delete;

  // Forward declarations of member functions which are added in the playlist.cpp file.
  void PrintMenu(const string& title) const;
  void AddSong(const string& id, const string& song, const string& artist, int length);
  void RemoveSong();
  void ChangePositionSong();
  void OutputSongsByArtist() const;
  void OutputTotalTime() const;
  void OutputFullPlaylist() const;
};