#include "Playlist.h"
#include <iostream>

using namespace std;

// Print the menu options to the user.
void Playlist::PrintMenu(const string& title) const {
  cout << title << " PLAYLIST MENU" << endl;
  // Displaying all the menu options.
  cout << "a - Add song" << endl;
  cout << "d - Remove song" << endl;
  cout << "c - Change position of song" << endl;
  cout << "s - Output songs by specific artist" << endl;
  cout << "t - Output total time of playlist (in seconds)" << endl;
  cout << "o - Output full playlist" << endl;
  cout << "q - Quit" << endl << endl;
  cout << "Choose an option:" << endl;
}

// Add a song to the playlist.
void Playlist::AddSong(const string& id, const string& song, const string& artist, int length) {
  // Creating a new node for the playlist
  PlaylistNode *newNode = new PlaylistNode(id, song, artist, length);
  // If the playlist is empty, set this node as the head and tail.
  if (head == nullptr) {
    head = newNode;
    tail = newNode;
    newNode->nextNodePtr = nullptr; // Explicitly setting next pointer to null for clarity
  } else {
    // Append the new node to the end of the list and update tail.
    tail->nextNodePtr = newNode;
    tail = newNode;
    tail->nextNodePtr = nullptr;
  }
}

// Remove a song from the playlist based on its unique ID.
void Playlist::RemoveSong() {
  cout << "Enter song's unique ID:" << endl;
  string removeID;
  cin >> removeID; // User inputs the ID of the song to be removed.
  int counter = 0; // To check if the song was found and removed.

  if (head == nullptr) {
    cout << "Empty Playlist" << endl;
    return;
  }

  PlaylistNode *curr = head;
  PlaylistNode *prev = nullptr;

  while (curr != nullptr) {
    if (curr->GetID() == removeID) {
      // Song found; proceed to remove it.
      if (curr == head) {
        head = curr->nextNodePtr;
      }
      if (curr == tail) {
        tail = prev;
      }
      if (prev != nullptr) {
        prev->nextNodePtr = curr->nextNodePtr;
      }
      cout << "\"" << curr->GetSongName() << "\" removed." << endl;
      cout << endl;
      delete curr; // Freeing the memory.
      counter++;
      break; // Break as the song to remove is found.
    }
    prev = curr;
    curr = curr->nextNodePtr;
  }

}

// Change the position of a song in the playlist.
void Playlist::ChangePositionSong() {
  // Checks if the playlist is too short to rearrange
  if (head == nullptr || head->nextNodePtr == nullptr) {
    cout << "No position to change." << endl;
    return;
  }

  cout << "Enter song's current position:" << endl;
  int currPosition;
  cin >> currPosition;
  cout << "Enter new position for song:" << endl;
  int newPosition;
  int length = 0;
  cin >> newPosition;
  
  // Check if the user is inserting the song into the same place
  if (newPosition == currPosition) {
    cout << "No change needed." << endl;
    return;
  }

  PlaylistNode* curr = head;
  PlaylistNode* prevCurrent = nullptr;
  int posFind = 1; // Start positions from 1, not 0. Also finds the current song's position
  while (curr != nullptr && posFind < currPosition) {
    prevCurrent = curr;
    curr = curr->nextNodePtr;
    posFind++;
  }
  // Used to verify length
  PlaylistNode* currCounting = head;

  while(currCounting != nullptr){
    length++;
    currCounting = currCounting->nextNodePtr;
  }
  // Error if new position does not exist
  if(newPosition > length || newPosition < 0){
    cout << "Position does not exist please select another position" << endl;
  }
  // If the song is not found
  if(curr == nullptr){
    cout << "Song does not exist. Please choose a song from your playlist!" << endl;
  }
  // If current is not the head of the list
  if (prevCurrent != nullptr) {//disconect current node from the list
    prevCurrent->nextNodePtr = curr->nextNodePtr;
  } else { // directly sets the head to next node
    head = curr->nextNodePtr;
  }
  // Updates tail if current position is the last node
  if (curr == tail){
    tail = prevCurrent;
  }

  PlaylistNode* newPositionNode = head; // will traverse the list to find new position for current node
  PlaylistNode* prevNewPosition = nullptr; // keep track of the node previous to newPositionNode as it goes down the list
  int currPositionFind = 1; // finds new insertion point
  while (newPositionNode != nullptr && currPositionFind < newPosition) { // go until the position is found
    prevNewPosition = newPositionNode; // Updates just before insertion
    newPositionNode = newPositionNode->nextNodePtr;
    currPositionFind++;
  }
  
  // If new position is not at the beginning of the list
  if (prevNewPosition != nullptr) { // Adjusts the pointers so curr is inserted into the new position
    curr->nextNodePtr = prevNewPosition->nextNodePtr;
    prevNewPosition->nextNodePtr = curr;
  } else { // if inserting at the head, updates the head to current position
    curr->nextNodePtr = head;
    head = curr;
  }
  // Updates tail if new position is the last node
  if(newPositionNode == nullptr){
    tail = curr;
  }

  cout << "\"" << curr->GetSongName() << "\" moved to position " << newPosition << endl;
  cout << endl;
}

// Output all songs by a specific artist.
void Playlist::OutputSongsByArtist() const {
  string artistName;
  cout << "Enter artist's name:" << endl;
  cout << endl;
  cin.ignore(); // Ignore newline left in the input buffer
  getline(cin, artistName); // Get full artist name
  if (head == nullptr) {
    cout << "Playlist is empty" << endl;
    return;
  }
  // Edge case: If there's only one song from the requested artist available
  if(head->nextNodePtr == nullptr && head->GetArtistName() == artistName){
    head->PrintPlaylistNode(); // Print details of the song
  }
  //Goes through the playlist nodes
  PlaylistNode *curr = head;
  int counter = 1;// Counts the song's position
  while (curr != nullptr) {
    if (curr->GetArtistName() == artistName) {
      cout << counter << ".";// Position number
      curr->PrintPlaylistNode(); // Prints Song Details
    }
    curr = curr->nextNodePtr;
    counter++;
  }
}

// Calculate the total time of all songs in the playlist.
void Playlist::OutputTotalTime() const {
  if (head == nullptr) {
    cout << "0 total time" << endl; // If the playlist is empty, output total time as 0
    return;
  }

  //If there's only one song, print its length
  if(head->nextNodePtr == nullptr){
    cout << "Total Time:" << head->GetSongLength() << " seconds" << endl;
    cout << endl;
  } else{
    int totalSeconds = 0;
    for (const PlaylistNode *curr = head; curr != nullptr; curr = curr->GetNext()) {
      totalSeconds += curr->GetSongLength(); // Sum the length of each song
    }
    cout << "Total time: " << totalSeconds << " seconds" << endl;
    cout << endl;
  }
}

// Output the full playlist.
void Playlist::OutputFullPlaylist() const {
  if (head == nullptr) {
    cout << endl;
    cout << "Playlist is empty" << endl; // There are no songs on playlist to output
    cout << endl;
    return;
  }

  //Edge case: if one song is available print that one song
  if(head->nextNodePtr == nullptr){
    cout << endl << "1.";
    head->PrintPlaylistNode();
  } else{
    int position = 1;
    PlaylistNode *curr = head;
    cout << endl;
    while (curr != nullptr) {
      cout << position << ".";
      curr->PrintPlaylistNode(); // Prints position before song details
      curr = curr->nextNodePtr; 
      position++;
    }
  }
}