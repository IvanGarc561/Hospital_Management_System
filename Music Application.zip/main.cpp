#include <iostream>
#include "Playlist.h"

using namespace std;

int main() {
  // Variable to hold the playlist title entered by the user.
  string title;
  cout << "Enter playlist's title:" << endl;
  cout << endl;
  getline(cin, title);

  // Create a Playlist object.
  Playlist P;

  string choice;

  // Continue displaying the menu until the user decides to quit ('q').
  while(choice != "q"){
    P.PrintMenu(title);  // Display the menu options to the user.
    cin >> choice;

    if (choice == "a") {
      // Variables that hold song details.
      string addID, addSongName, addArtistName;
      int addLength;

      cout << "ADD SONG" << endl;
      cout << "Enter song's unique ID:" << endl;
      cin >> addID;
      cin.ignore();  // Clear input buffer to correctly use getline next.

      cout << "Enter song's name:" << endl;
      getline(cin, addSongName);

      cout << "Enter artist's name:" << endl;
      getline(cin, addArtistName);

      cout << "Enter song's length (in seconds):" << endl;
      cout << endl;
      cin >> addLength;

      // Add the song to the playlist with the collected details.
      P.AddSong(addID, addSongName, addArtistName, addLength);
    } 
    if (choice == "d") {
      cout << "REMOVE SONG" << endl;
      P.RemoveSong();  // Call the function to remove a song.
    } 
    if (choice == "c") {
      cout << "CHANGE POSITION OF SONG" << endl;
      P.ChangePositionSong();  // Change the position of a song within the playlist.
    } 
    if (choice == "s") {
      cout << "OUTPUT SONGS BY SPECIFIC ARTIST" << endl;
      P.OutputSongsByArtist();  // Output all songs by a specific artist.
    } 
    if (choice == "t") {
      cout << "OUTPUT TOTAL TIME OF PLAYLIST (IN SECONDS)" << endl;
      P.OutputTotalTime();  // Output the total time of all songs in the playlist.
    } 
    if (choice == "o") {
      cout << title <<  " - OUTPUT FULL PLAYLIST";
      P.OutputFullPlaylist();  // Display all songs in the playlist.
    } 
  }

  // If cin is in an error state (even end-of-file), then
  // something went wrong
  if (!cin) {
    cout << "Program did not exit cleanly" << endl;
    return 1;
  }
  
  return 0;
}
